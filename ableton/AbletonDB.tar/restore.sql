create temporary table pgdump_restore_path(p text);
--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
-- Edit the following to match the path where the
-- tar archive has been extracted.
--
insert into pgdump_restore_path values('/tmp');

--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = ableton, pg_catalog;

ALTER TABLE ONLY ableton."WrongLogins" DROP CONSTRAINT "WrongLogins_user_id_fkey";
ALTER TABLE ONLY ableton."Users" DROP CONSTRAINT "Users_user_type_fkey";
ALTER TABLE ONLY ableton."Contents" DROP CONSTRAINT "Contents_owner_id_fkey";
ALTER TABLE ONLY ableton."Contents" DROP CONSTRAINT "Contents_allow_user_type_fkey";
ALTER TABLE ONLY ableton."WrongLogins" DROP CONSTRAINT "WrongLogins_pkey";
ALTER TABLE ONLY ableton."Users" DROP CONSTRAINT "Users_pkey";
ALTER TABLE ONLY ableton."Users" DROP CONSTRAINT "Users_email_key";
ALTER TABLE ONLY ableton."UserTypes" DROP CONSTRAINT "UserTypes_pkey";
ALTER TABLE ONLY ableton."UserTypes" DROP CONSTRAINT "UserTypes_description_key";
ALTER TABLE ONLY ableton."TempUsers" DROP CONSTRAINT "PK_TempUsers";
ALTER TABLE ONLY ableton."Contents" DROP CONSTRAINT "Contents_pkey";
ALTER TABLE ableton."Users" ALTER COLUMN user_type DROP DEFAULT;
ALTER TABLE ableton."Users" ALTER COLUMN user_id DROP DEFAULT;
ALTER TABLE ableton."UserTypes" ALTER COLUMN type_id DROP DEFAULT;
DROP TABLE ableton."WrongLogins";
DROP SEQUENCE ableton."Users_user_type_seq";
DROP SEQUENCE ableton."Users_user_id_seq";
DROP TABLE ableton."Users";
DROP SEQUENCE ableton."UserTypes_type_id_seq";
DROP TABLE ableton."UserTypes";
DROP TABLE ableton."TempUsers";
DROP TABLE ableton."Contents";
DROP SEQUENCE ableton."Contents_content_id_seq";
SET search_path = public, pg_catalog;

DROP FUNCTION public.test(arg1 integer);
DROP FUNCTION public.plpgsql_call_handler();
SET search_path = ableton, pg_catalog;

DROP FUNCTION ableton.wrong_login("user" bigint);
DROP FUNCTION ableton.new_user(user_email character varying, usertype character varying);
DROP FUNCTION ableton.new_user(user_email character varying);
DROP FUNCTION ableton.new_temp_user(email character varying, pass character varying);
DROP FUNCTION ableton.get_content(content_id bigint, "user" bigint);
DROP PROCEDURAL LANGUAGE plpgsql;
DROP SCHEMA public;
DROP SCHEMA ableton;
--
-- Name: ableton; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA ableton;


ALTER SCHEMA ableton OWNER TO postgres;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: PROCEDURAL LANGUAGE; Schema: -; Owner: postgres
--

CREATE PROCEDURAL LANGUAGE plpgsql;


ALTER PROCEDURAL LANGUAGE plpgsql OWNER TO postgres;

SET search_path = ableton, pg_catalog;

--
-- Name: get_content(bigint, bigint); Type: FUNCTION; Schema: ableton; Owner: postgres
--

CREATE FUNCTION get_content(content_id bigint, "user" bigint) RETURNS record
    AS $$
DECLARE
contents RECORD;
BEGIN

select c.value into contents 
from ableton."Contents" c
	inner join (select ut.type_id 
		    from ableton."Users" u
			inner join ableton."UserTypes" ut
			on u.user_type = ut.type_id
		    where u.user_id = "user") as uut
	on c.allow_user_type = uut.type_id
where c.content_id = "content_id";

if FOUND then
	return contents;
end if;

select "value" into contents
from ableton."Contents"
where content_id = "content_id"
	and owner_id = "user";

return contents;

END;
$$
    LANGUAGE plpgsql;


ALTER FUNCTION ableton.get_content(content_id bigint, "user" bigint) OWNER TO postgres;

--
-- Name: new_temp_user(character varying, character varying); Type: FUNCTION; Schema: ableton; Owner: postgres
--

CREATE FUNCTION new_temp_user(email character varying, pass character varying) RETURNS boolean
    AS $$
DECLARE
BEGIN
	if (select u.email from ableton."Users" u where u.email = email) is not null then
		raise notice 'User already registered.';
		return false;
	end if;

	if (select tu.email from ableton."TempUsers" tu where tu.email = email) is not null then
		raise notice 'Temporary User already created.';
		return false;
	end if;

	insert into ableton."TempUsers"
	values (email, pass, (select localtimestamp + '0 00:15:00'));

	raise notice 'Temporary User created.';
	return true;
END
$$
    LANGUAGE plpgsql;


ALTER FUNCTION ableton.new_temp_user(email character varying, pass character varying) OWNER TO postgres;

--
-- Name: new_user(character varying); Type: FUNCTION; Schema: ableton; Owner: postgres
--

CREATE FUNCTION new_user(user_email character varying) RETURNS boolean
    AS $$
DECLARE
new_user record;
USER_TYPE character varying := 'registered';
BEGIN

select tu.expires_at into new_user from ableton."TempUsers" tu where tu.email = user_email;

if NOT FOUND then
	raise notice 'Email not verified.';
	return FALSE;
end if;

if new_user.expires_at < localtime then
	raise notice 'Email validation expired.';
	delete from ableton."TempUsers"
	where email = user_email;
	
	return FALSE;
end if;

RETURN (select ableton.new_user(user_email, USER_TYPE));

END;
$$
    LANGUAGE plpgsql;


ALTER FUNCTION ableton.new_user(user_email character varying) OWNER TO postgres;

--
-- Name: new_user(character varying, character varying); Type: FUNCTION; Schema: ableton; Owner: postgres
--

CREATE FUNCTION new_user(user_email character varying, usertype character varying) RETURNS boolean
    AS $$

BEGIN

if (select TRUE from ableton."TempUsers" where email = user_email) then
	insert into ableton."Users" (email, "password", "user_type")
	select tu.email, tu."password", ut.type_id
	from ableton."TempUsers" tu
		inner join ableton."UserTypes" ut
		on ut.description = usertype
	where email = user_email;

	delete from ableton."TempUsers"
	where email = user_email;

	return TRUE;
end if;

raise notice 'Email not verified.';
return FALSE;

END;
$$
    LANGUAGE plpgsql;


ALTER FUNCTION ableton.new_user(user_email character varying, usertype character varying) OWNER TO postgres;

--
-- Name: wrong_login(bigint); Type: FUNCTION; Schema: ableton; Owner: postgres
--

CREATE FUNCTION wrong_login("user" bigint) RETURNS integer
    AS $$
DECLARE

MAX_ATTEMPTS CONSTANT smallint := 5;
attempts_left smallint := MAX_ATTEMPTS;
user_attempts record;
BEGIN
select attempts into user_attempts from ableton."WrongLogins" where user_id = "user";
if NOT FOUND then
	insert into ableton."WrongLogins" (user_id, attempts)
	values ("user", 0);
end if;

update ableton."WrongLogins" set attempts = attempts + 1
where user_id = "user";

select into attempts_left MAX_ATTEMPTS - attempts from ableton."WrongLogins"
where user_id = "user";

if attempts_left = 0 then
	update ableton."WrongLogins" 
	set hold_until = (select localtimestamp + '0 00:15:00')
	where user_id = "user";
end if;

return greatest(attempts_left, 0);

END;
$$
    LANGUAGE plpgsql;


ALTER FUNCTION ableton.wrong_login("user" bigint) OWNER TO postgres;

SET search_path = public, pg_catalog;

--
-- Name: plpgsql_call_handler(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION plpgsql_call_handler() RETURNS language_handler
    AS '/usr/lib/postgresql/8.3/lib/plpgsql.so', 'plpgsql_call_handler'
    LANGUAGE c;


ALTER FUNCTION public.plpgsql_call_handler() OWNER TO postgres;

--
-- Name: test(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION test(arg1 integer) RETURNS record
    AS $$
DECLARE
  A_SOMMAR integer := 4;
  RETORNO record;
  GONE integer;
  GONE_TOO character;
BEGIN

  gone := arg1 + A_SOMMAR;
  gone_too := 'a';

  RETORNO := (gone, gone_too);

  if abs(gone) % 2 = 1 then
	return RETORNO;
  else
    return RETORNO;
  end if;
END; 
$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.test(arg1 integer) OWNER TO postgres;

SET search_path = ableton, pg_catalog;

--
-- Name: Contents_content_id_seq; Type: SEQUENCE; Schema: ableton; Owner: postgres
--

CREATE SEQUENCE "Contents_content_id_seq"
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1
    CYCLE;


ALTER TABLE ableton."Contents_content_id_seq" OWNER TO postgres;

--
-- Name: Contents_content_id_seq; Type: SEQUENCE SET; Schema: ableton; Owner: postgres
--

SELECT pg_catalog.setval('"Contents_content_id_seq"', 2, true);


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: Contents; Type: TABLE; Schema: ableton; Owner: postgres; Tablespace: 
--

CREATE TABLE "Contents" (
    content_id bigint DEFAULT nextval('"Contents_content_id_seq"'::regclass) NOT NULL,
    value text NOT NULL,
    owner_id bigint NOT NULL,
    allow_user_type integer NOT NULL
);


ALTER TABLE ableton."Contents" OWNER TO postgres;

--
-- Name: TempUsers; Type: TABLE; Schema: ableton; Owner: postgres; Tablespace: 
--

CREATE TABLE "TempUsers" (
    email character varying NOT NULL,
    password character varying(20) NOT NULL,
    expires_at time without time zone DEFAULT (('now'::text)::timestamp without time zone + '00:15:00'::interval) NOT NULL
);


ALTER TABLE ableton."TempUsers" OWNER TO postgres;

--
-- Name: UserTypes; Type: TABLE; Schema: ableton; Owner: postgres; Tablespace: 
--

CREATE TABLE "UserTypes" (
    type_id integer NOT NULL,
    description character varying(20) NOT NULL
);


ALTER TABLE ableton."UserTypes" OWNER TO postgres;

--
-- Name: UserTypes_type_id_seq; Type: SEQUENCE; Schema: ableton; Owner: postgres
--

CREATE SEQUENCE "UserTypes_type_id_seq"
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE ableton."UserTypes_type_id_seq" OWNER TO postgres;

--
-- Name: UserTypes_type_id_seq; Type: SEQUENCE OWNED BY; Schema: ableton; Owner: postgres
--

ALTER SEQUENCE "UserTypes_type_id_seq" OWNED BY "UserTypes".type_id;


--
-- Name: UserTypes_type_id_seq; Type: SEQUENCE SET; Schema: ableton; Owner: postgres
--

SELECT pg_catalog.setval('"UserTypes_type_id_seq"', 5, true);


--
-- Name: Users; Type: TABLE; Schema: ableton; Owner: postgres; Tablespace: 
--

CREATE TABLE "Users" (
    user_id bigint NOT NULL,
    email character varying NOT NULL,
    password character varying(20) NOT NULL,
    user_type integer NOT NULL
);


ALTER TABLE ableton."Users" OWNER TO postgres;

--
-- Name: Users_user_id_seq; Type: SEQUENCE; Schema: ableton; Owner: postgres
--

CREATE SEQUENCE "Users_user_id_seq"
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE ableton."Users_user_id_seq" OWNER TO postgres;

--
-- Name: Users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: ableton; Owner: postgres
--

ALTER SEQUENCE "Users_user_id_seq" OWNED BY "Users".user_id;


--
-- Name: Users_user_id_seq; Type: SEQUENCE SET; Schema: ableton; Owner: postgres
--

SELECT pg_catalog.setval('"Users_user_id_seq"', 16, true);


--
-- Name: Users_user_type_seq; Type: SEQUENCE; Schema: ableton; Owner: postgres
--

CREATE SEQUENCE "Users_user_type_seq"
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE ableton."Users_user_type_seq" OWNER TO postgres;

--
-- Name: Users_user_type_seq; Type: SEQUENCE OWNED BY; Schema: ableton; Owner: postgres
--

ALTER SEQUENCE "Users_user_type_seq" OWNED BY "Users".user_type;


--
-- Name: Users_user_type_seq; Type: SEQUENCE SET; Schema: ableton; Owner: postgres
--

SELECT pg_catalog.setval('"Users_user_type_seq"', 1, false);


--
-- Name: WrongLogins; Type: TABLE; Schema: ableton; Owner: postgres; Tablespace: 
--

CREATE TABLE "WrongLogins" (
    user_id bigint NOT NULL,
    attempts smallint DEFAULT 0 NOT NULL,
    hold_until timestamp without time zone
);


ALTER TABLE ableton."WrongLogins" OWNER TO postgres;

--
-- Name: type_id; Type: DEFAULT; Schema: ableton; Owner: postgres
--

ALTER TABLE "UserTypes" ALTER COLUMN type_id SET DEFAULT nextval('"UserTypes_type_id_seq"'::regclass);


--
-- Name: user_id; Type: DEFAULT; Schema: ableton; Owner: postgres
--

ALTER TABLE "Users" ALTER COLUMN user_id SET DEFAULT nextval('"Users_user_id_seq"'::regclass);


--
-- Name: user_type; Type: DEFAULT; Schema: ableton; Owner: postgres
--

ALTER TABLE "Users" ALTER COLUMN user_type SET DEFAULT nextval('"Users_user_type_seq"'::regclass);


--
-- Data for Name: Contents; Type: TABLE DATA; Schema: ableton; Owner: postgres
--

COPY "Contents" (content_id, value, owner_id, allow_user_type) FROM stdin;
\.
copy "contents" (content_id, value, owner_id, allow_user_type)  from '$$PATH$$/1789.dat' ;
--
-- Data for Name: TempUsers; Type: TABLE DATA; Schema: ableton; Owner: postgres
--

COPY "TempUsers" (email, password, expires_at) FROM stdin;
\.
copy "tempusers" (email, password, expires_at)  from '$$PATH$$/1787.dat' ;
--
-- Data for Name: UserTypes; Type: TABLE DATA; Schema: ableton; Owner: postgres
--

COPY "UserTypes" (type_id, description) FROM stdin;
\.
copy "usertypes" (type_id, description)  from '$$PATH$$/1785.dat' ;
--
-- Data for Name: Users; Type: TABLE DATA; Schema: ableton; Owner: postgres
--

COPY "Users" (user_id, email, password, user_type) FROM stdin;
\.
copy "users" (user_id, email, password, user_type)  from '$$PATH$$/1786.dat' ;
--
-- Data for Name: WrongLogins; Type: TABLE DATA; Schema: ableton; Owner: postgres
--

COPY "WrongLogins" (user_id, attempts, hold_until) FROM stdin;
\.
copy "wronglogins" (user_id, attempts, hold_until)  from '$$PATH$$/1788.dat' ;
--
-- Name: Contents_pkey; Type: CONSTRAINT; Schema: ableton; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY "Contents"
    ADD CONSTRAINT "Contents_pkey" PRIMARY KEY (content_id);


--
-- Name: PK_TempUsers; Type: CONSTRAINT; Schema: ableton; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY "TempUsers"
    ADD CONSTRAINT "PK_TempUsers" PRIMARY KEY (email);


--
-- Name: UserTypes_description_key; Type: CONSTRAINT; Schema: ableton; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY "UserTypes"
    ADD CONSTRAINT "UserTypes_description_key" UNIQUE (description);


--
-- Name: UserTypes_pkey; Type: CONSTRAINT; Schema: ableton; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY "UserTypes"
    ADD CONSTRAINT "UserTypes_pkey" PRIMARY KEY (type_id);


--
-- Name: Users_email_key; Type: CONSTRAINT; Schema: ableton; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY "Users"
    ADD CONSTRAINT "Users_email_key" UNIQUE (email);


--
-- Name: Users_pkey; Type: CONSTRAINT; Schema: ableton; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY "Users"
    ADD CONSTRAINT "Users_pkey" PRIMARY KEY (user_id);


--
-- Name: WrongLogins_pkey; Type: CONSTRAINT; Schema: ableton; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY "WrongLogins"
    ADD CONSTRAINT "WrongLogins_pkey" PRIMARY KEY (user_id);


--
-- Name: Contents_allow_user_type_fkey; Type: FK CONSTRAINT; Schema: ableton; Owner: postgres
--

ALTER TABLE ONLY "Contents"
    ADD CONSTRAINT "Contents_allow_user_type_fkey" FOREIGN KEY (allow_user_type) REFERENCES "UserTypes"(type_id);


--
-- Name: Contents_owner_id_fkey; Type: FK CONSTRAINT; Schema: ableton; Owner: postgres
--

ALTER TABLE ONLY "Contents"
    ADD CONSTRAINT "Contents_owner_id_fkey" FOREIGN KEY (owner_id) REFERENCES "Users"(user_id);


--
-- Name: Users_user_type_fkey; Type: FK CONSTRAINT; Schema: ableton; Owner: postgres
--

ALTER TABLE ONLY "Users"
    ADD CONSTRAINT "Users_user_type_fkey" FOREIGN KEY (user_type) REFERENCES "UserTypes"(type_id);


--
-- Name: WrongLogins_user_id_fkey; Type: FK CONSTRAINT; Schema: ableton; Owner: postgres
--

ALTER TABLE ONLY "WrongLogins"
    ADD CONSTRAINT "WrongLogins_user_id_fkey" FOREIGN KEY (user_id) REFERENCES "Users"(user_id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

